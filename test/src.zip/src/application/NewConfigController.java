package application;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.*;
import javafx.collections.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;

public class NewConfigController implements Initializable{

    @FXML
    private ToggleGroup GAtg;

    @FXML
    private ToggleGroup GAtg1;

    @FXML
    private ToggleGroup GAtg11;

    @FXML
    private ToggleGroup GAtg111;

    @FXML
    private TextField starttime;

    @FXML
    private TextField endtime;

    @FXML
    private TextField schedtim;
    

    @FXML
    private RadioButton bit16;

    @FXML
    private RadioButton bit24;

    @FXML
    private RadioButton khz105;

    @FXML
    private RadioButton khz52;
    
    @FXML
    private ListView<String> list;
    
    @FXML
    void contTimes() {
    	starttime.setDisable(false);
    	endtime.setDisable(false);
    	schedtim.setDisable(true);
    }

    @FXML
    void manTimes() {
    	
    	starttime.setDisable(true);
    	endtime.setDisable(true);
    	schedtim.setDisable(true);
    }

    @FXML
    void schedTimes() {
    	starttime.setDisable(true);
    	endtime.setDisable(true);
    	schedtim.setDisable(false);
    }
    //THIS IS 24 BIT SELECTED RENAME LATER
    @FXML
    void khz105select(){
    	if(khz105.isSelected()== true)
    		khz105.setSelected(false);
    	khz105.setDisable(true);
    	khz52.setDisable(false);
    	
    	
    }
    //THIS IS 16 BIT SELECTED RENAME LATER

    @FXML
    void khz52select(){
    	khz105.setDisable(false);
    	khz52.setDisable(false);
    }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		List<String> values = Arrays.asList("one", "two", "three");

        list.setItems(FXCollections.observableList(values));
	
	
	}

}

